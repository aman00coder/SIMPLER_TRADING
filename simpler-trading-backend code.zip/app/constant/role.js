export const ROLE_MAP = {
  ADMIN: 1,
  STREAMER: 2,
  VIEWER: 3
};

export const ROLE_REVERSE_MAP = {
  1: "ADMIN",
  2: "STREAMER",
  3: "VIEWER"
};
