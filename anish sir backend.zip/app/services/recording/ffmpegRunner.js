// import { spawn } from "child_process";

// export const startFFmpeg = ({ videoSdp, audioSdps, output }) => {
//   const args = [
//     "-y",
//     "-loglevel", "warning",
//     "-stats",
//     "-fflags", "nobuffer",
//     "-flags", "low_delay",
//     "-max_delay", "500000",
//     "-rw_timeout", "5000000",
//     "-use_wallclock_as_timestamps", "1",
//     "-analyzeduration", "10000000",
//     "-probesize", "10000000",
//     "-protocol_whitelist", "file,udp,rtp,pipe",
//     "-i", videoSdp
//   ];

//   audioSdps.forEach((sdp) => {
//     args.push(
//       "-protocol_whitelist", "file,udp,rtp,pipe",
//       "-i", sdp
//     );
//   });

//   if (audioSdps.length > 0) {
//     args.push(
//       "-filter_complex",
//       `${audioSdps.map((_, i) => `[${i + 1}:a]`).join("")}amix=inputs=${audioSdps.length}:dropout_transition=0[a]`,
//       "-map", "0:v",
//       "-map", "[a]"
//     );
//   } else {
//     args.push("-map", "0:v");
//   }

//   args.push(
//     "-c:v", "libvpx-vp9",
//     "-quality", "realtime",
//     "-speed", "8",
//     "-row-mt", "1",
//     "-tile-columns", "4",
//     "-frame-parallel", "1",
//     "-threads", "8",
//     "-lag-in-frames", "0",
//     "-b:v", "2500k",
//     "-maxrate", "3500k",
//     "-minrate", "1000k",
//     "-crf", "30",
//     "-g", "120",
//     "-c:a", "libopus",
//     "-b:a", "128k",
//     "-ar", "48000",
//     "-f", "webm",
//     output
//   );

//   console.log("🎬 FFmpeg WebM command:\nffmpeg", args.join(" "));

//   const ffmpeg = spawn("ffmpeg", args, {
//     stdio: ["ignore", "pipe", "pipe"]
//   });

//   ffmpeg.stderr.on("data", (data) => {
//     const line = data.toString().trim();
//     if (line && !line.includes("frame=")) {
//       console.log("🎥 FFmpeg:", line);
//     }
//   });

//   ffmpeg.on("error", (err) => {
//     console.error("❌ FFmpeg process error:", err.message);
//   });

//   return ffmpeg;
// };





// export const startFFmpeg = ({ videoSdp, audioSdps, output }) => {
//   const args = [
//     "-y",
    
//     // 1. INPUT BUFFERS (Zaroori hai taaki data drop na ho)
//     "-thread_queue_size", "4096",
//     "-protocol_whitelist", "file,udp,rtp,pipe",
//     "-i", videoSdp
//   ];

//   // Audio inputs add kar rahe hain
//   audioSdps.forEach((sdp) => {
//     args.push(
//       "-thread_queue_size", "4096",
//       "-protocol_whitelist", "file,udp,rtp,pipe",
//       "-i", sdp
//     );
//   });

//   // 2. AUDIO MAPPING (Audio mix karega par video ko disturb nahi karega)
//   if (audioSdps.length > 0) {
//     const inputMaps = audioSdps.map((_, i) => `[${i + 1}:a]`).join("");
//     args.push(
//       "-filter_complex",
//       // aresample=async=1000: Ye audio sync ko loose kar deta hai taaki video wait na kare
//       `${inputMaps}amix=inputs=${audioSdps.length}:dropout_transition=0,aresample=async=1000[a]`,
//       "-map", "0:v",
//       "-map", "[a]"
//     );
//   } else {
//     args.push("-map", "0:v");
//   }

//   args.push(
//     // 3. VIDEO - NO FREEZE SETTINGS (Sabse Important Section)
//     "-vsync", "1",       // Force Constant Frame Rate (Video kabhi wait nahi karega)
//     "-r", "30",          // Force 30 FPS output
    
//     // Codec VP8 use kar rahe hain (VP9 se fast hai, live ke liye best)
//     "-c:v", "libvpx",    
//     "-b:v", "2000k",
//     "-maxrate", "2500k",
//     "-bufsize", "4000k",
//     "-deadline", "realtime", // CPU ko bolta hai quality se zyada speed matter karti hai
//     "-cpu-used", "4",        // Encoding speed badhata hai
    
//     // 4. AUDIO SETTINGS
//     "-c:a", "libopus",
//     "-b:a", "64k",       // Bitrate kam kiya taaki CPU bache
//     "-ac", "2",
//     "-ar", "48000",
    
//     "-f", "webm",
//     output
//   );

//   console.log("🎬 FFmpeg Anti-Lag Command Running...");

//   const ffmpeg = spawn("ffmpeg", args, {
//     stdio: ["ignore", "pipe", "pipe"]
//   });

//   ffmpeg.stderr.on("data", (data) => {
//     // Sirf error logs dikhayein
//     const line = data.toString();
//     if (line.includes("Error") || line.includes("fps=")) {
//       // console.log(line); // Uncomment for debugging
//     }
//   });

//   ffmpeg.on("error", (err) => {
//     console.error("❌ FFmpeg process error:", err.message);
//   });

//   return ffmpeg;
// };




import { spawn } from "child_process";
export const startFFmpeg = ({ videoSdp, audioSdps, output }) => {
  const args = [
    "-y",
    
    // 1. INPUT BUFFERS (Zaroori hai taaki data drop na ho)
    "-thread_queue_size", "4096",
    "-protocol_whitelist", "file,udp,rtp,pipe",
    "-i", videoSdp
  ];

  // Audio inputs add kar rahe hain
  audioSdps.forEach((sdp) => {
    args.push(
      "-thread_queue_size", "4096",
      "-protocol_whitelist", "file,udp,rtp,pipe",
      "-i", sdp
    );
  });

  // 2. AUDIO MAPPING (Audio mix karega par video ko disturb nahi karega)
  if (audioSdps.length > 0) {
    const inputMaps = audioSdps.map((_, i) => `[${i + 1}:a]`).join("");
    args.push(
      "-filter_complex",
      // aresample=async=1000: Ye audio sync ko loose kar deta hai taaki video wait na kare
      `${inputMaps}amix=inputs=${audioSdps.length}:dropout_transition=0,aresample=async=1000[a]`,
      "-map", "0:v",
      "-map", "[a]"
    );
  } else {
    args.push("-map", "0:v");
  }

  args.push(
    // 3. VIDEO - NO FREEZE SETTINGS (Sabse Important Section)
    "-vsync", "1",       // Force Constant Frame Rate (Video kabhi wait nahi karega)
    "-r", "30",          // Force 30 FPS output
    
    // Codec VP8 use kar rahe hain (VP9 se fast hai, live ke liye best)
    "-c:v", "libvpx",    
    "-b:v", "2000k",
    "-maxrate", "2500k",
    "-bufsize", "4000k",
    "-deadline", "realtime", // CPU ko bolta hai quality se zyada speed matter karti hai
    "-cpu-used", "4",        // Encoding speed badhata hai
    
    // 4. AUDIO SETTINGS
    "-c:a", "libopus",
    "-b:a", "64k",       // Bitrate kam kiya taaki CPU bache
    "-ac", "2",
    "-ar", "48000",
    
    "-f", "webm",
    output
  );

  console.log("🎬 FFmpeg Anti-Lag Command Running...");

  const ffmpeg = spawn("ffmpeg", args, {
    stdio: ["ignore", "pipe", "pipe"]
  });

  ffmpeg.stderr.on("data", (data) => {
    // Sirf error logs dikhayein
    const line = data.toString();
    if (line.includes("Error") || line.includes("fps=")) {
      // console.log(line); // Uncomment for debugging
    }
  });

  ffmpeg.on("error", (err) => {
    console.error("❌ FFmpeg process error:", err.message);
  });

  return ffmpeg;
};



export const waitForFFmpegExit = (ffmpegProcess, timeoutMs = 10000) => {
  return new Promise((resolve, reject) => {
    let settled = false;

    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      console.warn("⚠️ FFmpeg exit timeout, force killing...");
      ffmpegProcess.kill("SIGKILL");
      resolve();
    }, timeoutMs);

    ffmpegProcess.once("close", (code, signal) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      console.log(`🎬 FFmpeg closed - Code: ${code}, Signal: ${signal}`);
      resolve();
    });

    ffmpegProcess.once("error", (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      reject(err);
    });
  });
};

export const killFFmpegProcess = (ffmpegProcess) => {
  if (!ffmpegProcess || ffmpegProcess.killed) return true;

  try {
    console.log("🛑 Sending SIGINT to FFmpeg...");
    ffmpegProcess.kill("SIGINT");

    setTimeout(() => {
      if (!ffmpegProcess.killed) {
        console.warn("🔄 Force killing FFmpeg (SIGKILL)...");
        ffmpegProcess.kill("SIGKILL");
      }
    }, 3000);

    return true;
  } catch (err) {
    console.error("❌ Error killing FFmpeg process:", err.message);
    return false;
  }
};